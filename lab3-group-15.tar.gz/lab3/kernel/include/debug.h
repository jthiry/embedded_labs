#ifndef DEBUG_H
#define DEBUG_H

extern int debug_enabled;

#endif
