/*
Authors: Joe Battaglia, Hans Reichanbach, Josh Thiry
Basic hello_world program for Lab1 section 6.1
*/

#include <stdio.h>		/* Standard input output library

int main() {

  printf("Hello World!\n");	/* Printing the string */
  return 0;			/* Terminating exit status 0 */
}
