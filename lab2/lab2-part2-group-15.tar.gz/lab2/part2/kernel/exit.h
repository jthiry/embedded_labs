#ifndef EXIT_H
#define EXIT_H

extern void _EXIT(int status);

#endif
