#ifndef S_HANDLER_H
#define S_HANDLER_H


extern void S_HANDLER(void);
extern int ENABLE_USER_PROG(unsigned stack_ptr);
extern unsigned CHECK_INST(unsigned vec_swi);
extern unsigned GET_IMM(unsigned vec_swi);

#endif
