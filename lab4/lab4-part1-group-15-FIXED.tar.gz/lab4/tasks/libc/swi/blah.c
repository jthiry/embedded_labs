#include <stdio.h>
#include <stdlib.h>

void printAss(void)
{
	puts("DEBUG::read wrapper--tick\n");
}
