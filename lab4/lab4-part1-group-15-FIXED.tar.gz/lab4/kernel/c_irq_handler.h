#ifndef C_IRQ_HANDLER_H
#define C_IRQ_HANDLER_H

//necessary libs

//prototypes
void c_irq_handler();
#endif
