/** @file main.c
 *
 * @brief kernel main
 *
 * @author  Joe Battaglia <JABAT295.gmail.com>
 *          Hans Reichenbach <HansReich.gmail.com>
 *          Josh Thiry <josh.thiry@gmail.com>
 *
 * @date    11/16/12
 */

#include <kernel.h>
#include <task.h>
#include <sched.h>
#include <device.h>
#include <assert.h>

/* copied over from lab3*/
#include <exports.h>
#include <arm/psr.h>
#include <arm/exception.h>
#include <arm/interrupt.h>
#include "swi_handler.h"
#include <arm/irq_handler.h>
#include "constants.h"
#include "kernel_util.h"
#include "c_kernel_util.h"

/* new includes*/
#include <arm/physmem.h>

uint32_t global_data;
uint32_t global_data2;

int kmain(int argc __attribute__((unused)), char** argv  __attribute__((unused)), uint32_t table)
{

	app_startup();
	global_data = table;
	/* add your code up to assert statement */


	/* Wiring in Data abort handler */
	if (-1 == wire_exception_handler(EX_FABRT)) {
	    printf ("ldr pc, [pc, #immed] not encountered at %d. Exiting.\n",
		    GET_EXP_VEC_ADDR(EX_FABRT));
	    return 0xbadc0de;
	}

	/* setup abort stack */
	setup_abort_stack();
	setup_irq_stack();
	//Our code starts here

	if (-1 == wire_exception_handler(EX_SWI)) {
	    printf ("ldr pc, [pc, #immed] not encountered at %d. Exiting.\n",
		    GET_EXP_VEC_ADDR(EX_SWI));
	    return 0xbadc0de;
	}


	// Wiring in irq handler
	if (-1 == wire_exception_handler(EX_IRQ)) {
	    printf ("ldr pc, [pc, #immed] not encountered at %d. Exiting.\n",
		    GET_EXP_VEC_ADDR(EX_FABRT));
	    return 0xbadc0de;
	}



	initialize_timer();

	//Set up the stack
	unsigned* stack_ptr = setup_stack( START_KERNEL, argc, argv);


	//devices initialization
	dev_init();

	//Start the user program
	int status = _enable_user_prog( (unsigned)stack_ptr, RAM_START_ADDR );

	uninitialize_timer();

	restore_handlers();


  //REMOVE THIS BEFORE SUBMITTING
  return status;

	assert(0);        /* should never get here */
}
