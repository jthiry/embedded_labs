#ifndef S_HANDLER_H
#define S_HANDLER_H


extern void S_HANDLER(void); 	//fucntion that acts as our swi handler

#endif
