#ifndef IRQ_HANDLER_H
#define IRQ_HANDLER_H

extern void irq_wrapper(void); 	//fucntion that acts as our swi handler

#endif
