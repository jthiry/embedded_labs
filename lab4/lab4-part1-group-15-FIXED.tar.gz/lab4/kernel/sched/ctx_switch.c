/** @file ctx_switch.c
 *
 * @brief C wrappers around assembly context switch routines.
 *
 *  @author  Joe Battaglia <JABAT295.gmail.com>
 *          Hans Reichenbach <HansReich.gmail.com>
 *          Josh Thiry <josh.thiry@gmail.com>
 * @date 2012-11-29
 */


#include <types.h>
#include <assert.h>

#include <config.h>
#include <kernel.h>
#include "sched_i.h"
#include <arm/exception.h>

#ifdef DEBUG_MUTEX
#include <exports.h>
#endif

static tcb_t* cur_tcb; /* use this if needed */

/**
 * @brief Initialize the current TCB and priority.
 *
 * Set the initialization thread's priority to IDLE so that anything
 * will preempt it when dispatching the first task.
 */
void dispatch_init(tcb_t* idle )
{
	cur_tcb = idle;
}


/**
 * @brief Context switch to the highest priority task while saving off the
 * current task state.
 *
 * This function needs to be externally synchronized.
 * We could be switching from the idle task.  The priority searcher has been tuned
 * to return IDLE_PRIO for a completely empty run_queue case.
 */
void dispatch_save(void)
{
	//save soon to be previous state for ctx switch
	tcb_t* prev_tcb = cur_tcb;

	//get the next task to run
	uint8_t h_prio = highest_prio();		        //get highest priority
	
	//add it back to runnable
	runqueue_add(prev_tcb, prev_tcb->cur_prio);
	
	cur_tcb = runqueue_remove(h_prio);		      //retrieve task while removing it from the run_queue

	ctx_switch_full(&cur_tcb->context, &prev_tcb->context);   			//call the context switch (target, current)
}

/**
 * @brief Context switch to the highest priority task that is not this task --
 * don't save the current task state.
 *
 * There is always an idle task to switch to.
 */
void dispatch_nosave(void)
{
	//get the next task to run
	uint8_t h_prio = highest_prio();	    //get highest priority
	cur_tcb = runqueue_remove(h_prio);	  //retrieve task while removing it from runqueue

	//run the next task
	ctx_switch_half(&cur_tcb->context);		          //call the half context switch

	//we should never return here
	puts("WE SHOULD NOT BE HERE ****\n");
}


/**
 * @brief Context switch to the highest priority task that is not this task --
 * and save the current task but don't mark is runnable.
 *
 * There is always an idle task to switch to.
 */
void dispatch_sleep(void)
{
	//save the soon to be previous tcb
	tcb_t* prev_tcb = cur_tcb;

	//get the next task to run
	uint8_t h_prio = highest_prio();		      //get highest priority
	cur_tcb = runqueue_remove(h_prio);		    //retrieve task while removing it from the runqueue

	//switch tasks
	ctx_switch_full(&cur_tcb->context, &prev_tcb->context);   		//call the context switch
}

/**
 * @brief Returns the priority value of the current task.
 */
uint8_t get_cur_prio(void)
{
	return cur_tcb->cur_prio;
}

/**
 * @brief Returns the TCB of the current task.
 */
tcb_t* get_cur_tcb(void)
{
	return cur_tcb;
}


uint32_t get_kstack(void)
{
	return (unsigned)&cur_tcb->kstack_high;
}
